const chalk = require('chalk')
const error = chalk.red
const errorLog = require('./handler/events/Logger.js').errorlog;
const successlog = require('./handler/events/Logger.js').successlog;

module.exports = (bot) => {
    process.on('unhandledRejection', (reason, p) => {
        console.log(`${chalk.red('[ antiCrash ]')} ${chalk.black(' :: ')} ${chalk.red('Prevented crash from error: Unhandled Rejection/Catch')}`);
        console.log(error(reason, p));
    });
    process.on("uncaughtException", (err, origin) => {
        console.log(`${chalk.red('[ antiCrash ]')} ${chalk.black(' :: ')} ${chalk.red('Prevented crash from error: Uncaught Exception/Catch')}`);
        console.log(error(err, origin));
    }); process.on('uncaughtExceptionMonitor', (err, origin) => {
        console.log(`${chalk.red('[ antiCrash ]')} ${chalk.black(' :: ')} ${chalk.red('Prevented crash from error: Uncaught Exception/Catch (MONITOR)')}`);
        console.log(error(err, origin));
    });
    process.on('multipleResolves', (type, promise, reason) => {
                console.log(`${chalk.red('[ antiCrash ]')} ${chalk.black(' :: ')} ${chalk.red('Prevented crash from error: Multiple Resolves')}`);;
    });
}
