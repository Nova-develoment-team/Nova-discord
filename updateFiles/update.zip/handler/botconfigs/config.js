module.exports = {
    Bot: {
    token: "ODk2MzAzOTQ3MzExMTA0MDQx.GFkX0I.wu1jg5aEIG3TXINTzoENqbyUERua1v5-_MC2b8",
    prefix: ["$GetServerVar[prefix]","<@$clientID>"],
    intents: "all", },
    respondOnEdit: {
        commands: true
    },
    debug: {
        interpreter : true 
},
    suppressAllErrors: {
        errorMessage: ["", "$log[[ERROR] :: $username had a error in $servername | ERROR ID: $randomString[$random[4;10]]]{newEmbed:{title:Ah oh!}{description:There was a error | ERROR ID: $randomString[$random[4;10]]}{color:fcbfcb}}"]
    },

  lava_settings: {
    Host: "127.0.0.1:3984", /*The lavalink host, Should not add https:// or http:// */
    Host_password: "NovaLavalink",  /* The lavalinkd host password */
    Debug: process.env.Lavalink_debug, /* Should be true or false */
    SSL: process.env.Lavalink_ssl /* Try if the lavalink server has https:// do true, if http:// do false */
  },

  website_settings: {
    tab_title: "Nova bot",
    embed_description: "Nova the best discord bot",
    domain: "https://dashboard.nova-bot.tk",
    Status_page: "https://status.nova-bot.tk",
    Bot_name: "Nova",
    Maintnance: "false"
  },

  dash_settings: {

    id: 896303947311104041, 
    secret: "jvjIGf1484IzsgO_o2DVtK-tOlJnpbDL",
    redirect: "http://104.219.234.163:3986/callback" 
    },    

  db_settings: {
   uri: "mongodb://admin:WB0mAPwohq@n2.luxxy.host:1802?authSource=admin" /* MongoDB atlast uri */
  }
}
