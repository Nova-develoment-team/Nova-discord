module.exports = {

    keys: [
     'euzjauwjaix' //private key
    ]
}