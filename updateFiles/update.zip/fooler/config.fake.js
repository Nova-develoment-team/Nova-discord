module.exports = {
    Bot: {
    token: "You thaught i would do this 💀 ",
    prefix: ["$getServerVar[prefix]","<@$clientID>"],
    intents: "all", },
    respondOnEdit: {
        commands: "stupid ass"
    },
    debug: {
        interpreter : "stop looking through the actuall config file lmao"
},
    suppressAllErrors: {
        errorMessage: ["", "GET L'ed fool"]
    }
}
