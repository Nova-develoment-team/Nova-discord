module.exports = ({
    name: "premium",
    code: `$description[Hello $username, would you like to help fund for nova and its apis?
    Becouse i am a broke person :( if you like nova dm duckey#4200 and purchase premium/gold.]
    
    $color[YELLOW]`
})