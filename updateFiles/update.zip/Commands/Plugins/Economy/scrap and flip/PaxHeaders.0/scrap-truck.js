67 path=Commands/Plugins/💰Economy/scrap and flip/scrap-truck.js
