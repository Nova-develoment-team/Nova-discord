54 path=Commands/Plugins/💰Economy/Buy/buy-lucky.js
