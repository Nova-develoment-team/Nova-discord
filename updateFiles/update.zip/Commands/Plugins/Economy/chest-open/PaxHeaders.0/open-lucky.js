62 path=Commands/Plugins/💰Economy/chest-open/open-lucky.js
