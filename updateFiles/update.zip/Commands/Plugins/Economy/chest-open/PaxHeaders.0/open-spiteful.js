65 path=Commands/Plugins/💰Economy/chest-open/open-spiteful.js
