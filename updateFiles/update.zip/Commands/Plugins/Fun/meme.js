module.exports = ({
name: "meme",
code: `$title[$jsonRequest[https://api.popcat.xyz/meme;title]]
$image[$jsonRequest[https://api.popcat.xyz/meme;image]]
$footer[Upvotes: $jsonRequest[https://api.popcat.xyz/meme;upvotes]]
<<<<<<< HEAD:Commands/Plugins/😂Fun/meme.js
$color[$GetServervar[color]]

$log[[DEBUG] :: $username, used the meme command]
`
=======
$color[RANDOM]`
>>>>>>> 10ace2e0b1aba75cf335f509df3e588ed530d341:Commands/Plugins/fun/meme.js
})