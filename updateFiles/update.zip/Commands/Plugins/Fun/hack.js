/*Dank memer like "extremely awesome" and "the best"(atleast for me)...And trust me, its dope af grin*/

module.exports = ({
name:"hack",
code:`**__Starting a dangerous Hack on $username[$mentioned[1]]__**
$editIn[3s;**Got the token of the user:**
$randomString[18];**Email of the user:**
$replaceText[$username; ;_;-1]@gmail.com;Password:
$randomString[7];**Recent contacts:**
$username[$randomUserID];**Most used word:**
$randomText[meme;lol;nah;lmao;dude;bruh;wut;nou];**Most recent dm message:**
$randomText[I think you are mad af;bye;Why u blocked me;I am mad];**Hacking medical records**;**Hacked Email(bypassed 2FA too)**;**Injecting Latest version of Corona into the account**;**Hacking microsoft account**;**Microsoft password: $randomText[ZapIsZap@Zap.com;IAmNoob@gmail.com;ByeBye@ok.co.in;$replaceText[$username; ;_;-1]IsSmart@yahoo.com]**;**Checking User Games**;**Plays $randomText[fortnite(....);subway surfers;temple run;clash of clans]**;**Hacking epic games account**;**Epic games account hacked and deleted**;**Discord IP:
$numberSeparator[$random[100000000;900000000];.]**;__The *totally* dangerous, risky and scary hack on $username[$mentioned[1]] is complete!__

But be safe, the police may come anytime soon now :rofl:]
$onlyIf[$mentioned[1]!=;Woah wait, where is the person who is to be hacked bruh]
$onlyIf[$authorID!=$mentioned[1];....hacking yourself?]
$log[[DEBUG] :: $username, used the hack command]
`})

