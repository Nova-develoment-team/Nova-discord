
module.exports = ({
 name:"jumbo" ,
 code:`

$image[$replaceText[$replaceText[$checkCondition[$isValidLink[https://cdn.discordapp.com/emojis/$advancedTextSplit[$message;:;3;>;1].gif]==true];true;https://cdn.discordapp.com/emojis/$advancedTextSplit[$message;:;3;>;1].gif];false;https://cdn.discordapp.com/emojis/$advancedTextSplit[$message;:;3;>;1]]]
$color[$GetServervar[color]]

$log[[DEBUG] :: $username, used the jumbo command]

 `
})