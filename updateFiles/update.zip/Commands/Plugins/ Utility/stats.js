module.exports = {
  name: "stats",
  aliases: ["stats","clientinfo"],
  code: `$thumbnail[$userAvatar[$clientID]]
  $color[$GETsERVERvAR[color]]
  $addTimestamp
 $description[
  \`\`\`
  Total commands used: $getGlobalUserVar[commandusersused]
  Total commands used by you: $getGlobalUserVar[commanduserused]
  Server info
  Server id: g5Z6y-2F6qRLS
  Server type: Primary
  Server Release: $djseval[require('os').release();yes]
  Server Platform: $djseval[require('os').platform();yes]
  Server Arch: $djseval[require('os').arch();yes]
  Server Cores: $djseval[require('os').cpus().length;yes]
  Server Ram: 4GB
  Ram usage: $ram
  Node version: $nodeVersion
  Server Uptime: $uptime
  \`\`\`]
$title[$userTag[$clientID] - \`($getVar[novaVersion])\`]
  $log[[DEBUG] :: $username, used the stats command]`
}