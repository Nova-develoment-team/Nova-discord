module.exports = ({
    type: "loopCommand",
    code: `
    $editmessage[1003199765846184016;{description:}{field:CPU:$cpu%}{field:ram:$rammb}{field:uptime:$uptime}{field:ping:$pingms}{field:dbping:$dbpingms}{footer:Updated every 3s}{color:BLUE};966305408576786524]
  
    `,
    executeOnStartup: true,
    every: 3000
    })
    
