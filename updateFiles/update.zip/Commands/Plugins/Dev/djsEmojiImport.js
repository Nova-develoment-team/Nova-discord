module.exports = ({
  name: "test",
  code: `Hi $djseval[${const emoji = require('./jsons/emoji.json')
  emoji.boost};yes]`
})