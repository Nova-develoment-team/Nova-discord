module.exports = ({
name: "help-giveaway",
code: `$title[🎉 Nova giveaway]
$description[giveaway ¦ start giveaway]
$color[$getServerVar[color]]
$log[[DEBUG] :: $username, used the giveaway help category command]`
})