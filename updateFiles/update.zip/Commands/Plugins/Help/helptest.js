module.exports = ({
    name: "help3",
    code: `$title[$randomtext[Join the support server!;Add me!]]
    $description[<:moderation:905787390302490624> [Moderation](https://fakelikeishere.lol) [>help-mod]
    <:reply:980147502529523752> Search for moderation commands]                `
})