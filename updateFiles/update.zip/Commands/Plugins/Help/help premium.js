module.exports = ({
    name: "help-premium",
    code: `
    $title[⭐ Nova premium]
    $description[PREMIUM COMMANDS CUMMING SOON]
    $color[$getServerVar[color]]
    $log[[DEBUG] :: $username, used the levelling help category command]`
})