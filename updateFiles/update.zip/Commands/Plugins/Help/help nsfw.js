module.exports = ({
name: "help-nsfw",
code: `$title[:flushed: Nova nsfw]
$description[ass ¦ nsfw
bdsm ¦ nsfw
boobs ¦ nsfw
blowjob ¦ nsfw
futanari ¦ nsfw
hentai ¦ nsfw
lewdneko ¦ nsfw
lewdbomb ¦ nsfw
succubus ¦ nsfw
tentacles ¦ nsfw
yuri ¦ nsfw]
$color[$getServerVar[color]]
$log[[DEBUG] :: $username, used the nsfw help category command]`
})