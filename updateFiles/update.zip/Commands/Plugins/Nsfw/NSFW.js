module.exports = [{
name: "ass",
code: `$title[Ass]
$description[$image[$jsonRequest[https://api.nova-bot.tk/nsfw/ass?key=$getVar[apikey];url]]]
$color[RANDOM]
$onlyNsfw[{description: Set nsfw first}{image:https://cdn.nova-bot.tk/image/VUglIClKjM.gif}{color:$getServerVar[color]}]

$log[[DEBUG] :: $username, was horny and used the ass command]`,
}, {
name: "bdsm",
code: `$title[bdsm]
$description[$image[$jsonRequest[https://api.nova-bot.tk/nsfw/bdsm?key=$getVar[apikey];url]]]
$color[RANDOM]
$onlyNsfw[{description: Set nsfw first}{image:https://cdn.nova-bot.tk/image/VUglIClKjM.gif}{color:$getServerVar[color]}]

$log[[DEBUG] :: $username, was horny and used the bdsm command]`,
}, {    
    name: "boobs",
code: `$title[boobs]
$description[$image[$jsonRequest[https://api.nova-bot.tk/nsfw/boobs?key=$getVar[apikey];url]]]
$color[RANDOM]
$onlyNsfw[{description: Set nsfw first}{image:https://cdn.nova-bot.tk/image/$getVar[apikey].gif}{color:$getServerVar[color]}]

$log[[DEBUG] :: $username, was horny and used the boobs command]`,
}, {
    name: "futanari",
code: `$title[futanari]
$description[$image[$jsonRequest[https://api.nova-bot.tk/nsfw/futanari?key=$getVar[apikey];url]]]
$color[RANDOM]
$onlyNsfw[{description: Set nsfw first}{image:https://cdn.nova-bot.tk/image/VUglIClKjM.gif}{color:$getServerVar[color]}]

$log[[DEBUG] :: $username, was horny and used the futanari command]`,
}, {
    name: "hentai",
code: `$title[hentai]
$description[$image[$jsonRequest[https://api.nova-bot.tk/nsfw/hentai?key=$getVar[apikey];url]]]
$color[RANDOM]
$onlyNsfw[{description: Set nsfw first}{image:https://cdn.nova-bot.tk/image/VUglIClKjM.gif}{color:$getServerVar[color]}]

$log[[DEBUG] :: $username, was horny and used the hentai command]`,
}, {
        name: "lewdneko",
code: `$title[lewdneko]
$description[$image[$jsonRequest[https://api.nova-bot.tk/nsfw/lewdneko?key=$getVar[apikey];url]]]
$color[RANDOM]
$onlyNsfw[{description: Set nsfw first}{image:https://cdn.nova-bot.tk/image/VUglIClKjM.gif}{color:$getServerVar[color]}]

$log[[DEBUG] :: $username, was horny and used the lewdneko command]`,
}, {
    name: "succubus",
code: `$title[succubus]
$description[$image[$jsonRequest[https://api.nova-bot.tk/nsfw/succubus?key=$getVar[apikey];url]]]
$color[RANDOM]
$onlyNsfw[{description: Set nsfw first}{image:https://cdn.nova-bot.tk/image/VUglIClKjM.gif}{color:$getServerVar[color]}]

$log[[DEBUG] :: $username, was horny and used the succubus command]`,
}, {
    name: "tentacles",
code: `$title[tentacles]
$description[$image[$jsonRequest[https://api.nova-bot.tk/nsfw/tentacles?key=$getVar[apikey];url]]]
$color[RANDOM]
$onlyNsfw[{description: Set nsfw first}{image:https://cdn.nova-bot.tk/image/VUglIClKjM.gif}{color:$getServerVar[color]}]

$log[[DEBUG] :: $username, was horny and used the tentacles command]`,
}, {
    name: "yuri",
code: `$title[yuri]
$description[$image[$jsonRequest[https://api.nova-bot.tk/nsfw/yuri?key=$getVar[apikey];url]]]
$color[RANDOM]
$onlyNsfw[{description: Set nsfw first}{image:https://cdn.nova-bot.tk/image/VUglIClKjM.gif}{color:$getServerVar[color]}]

$log[[DEBUG] :: $username, was horny and used the yuri command]`,
}]