74 path=Commands/Plugins/🤖AutoModeration/antiSwear/Enable AntiSwear.js
