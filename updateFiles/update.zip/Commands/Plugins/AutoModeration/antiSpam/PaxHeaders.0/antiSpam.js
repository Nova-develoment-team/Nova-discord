65 path=Commands/Plugins/🤖AutoModeration/antiSpam/antiSpam.js
