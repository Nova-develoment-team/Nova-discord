module.exports = ({
    name: "lavaloop",
    code: `
    $if[$message[1]==]
    $replaceText[$lavalinkExecute[loopsong];$replaceText[$lavalinkExecute[loopsong];false;Successfully disabled loop on the track];Successfully looped track $lavalinkExecute[songinfo;title]]
    $suppressErrors[{title:Error}{description:CqMz3YhWuO || No songs playing to loop}{color:RED}]


    $elseif[$message[1]==queue]
$replaceText[$lavalinkExecute[loopqueue];true;Successfully looped the queue]
    $suppressErrors[{title:Error}{description:kWZV5V3dBM || No songs playing to loop the queue}{color:RED}]
    $endelseIf

    $endif`
})