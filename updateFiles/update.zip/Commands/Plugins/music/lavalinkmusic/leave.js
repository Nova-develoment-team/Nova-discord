module.exports = ({
    name: "lavaleave",
    code: `Left the vc
    $leavevc
    $lavalinkExecute[disconnect]
    $suppressErrors[{title:Error}{description:IDgqwm81ghA |\| No songs playing}{color:RED}]        `
})